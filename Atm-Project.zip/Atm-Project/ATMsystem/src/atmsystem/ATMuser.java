/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author acc1
 */
public class ATMuser extends Person {
    
    private Card ATMCard;
    private Account Acc;
    private float Balance;

    public ATMuser(Card ATMCard, float Balance, int id, String name, String Address, String Email) {
        super(id, name, Address, Email);
        this.ATMCard = ATMCard;
        this.Acc = Acc;
        this.Balance = Balance;
    }
    

    public Card getATMCard() {
        return ATMCard;
    }

    public void setATMCard(Card ATMCard) {
        this.ATMCard = ATMCard;
    }

    public Account getAcc() {
        return Acc;
    }

    public void setAcc(Account Acc) {
        this.Acc = Acc;
    }
    
       public float getBalance() {
        return Balance;
    }

    public void setBalance(float Balance) {
        this.Balance = Balance;
    }
    
    public static  void WithdrawCash(int l ,int id)
    { 
        int s=BalanceDA(id);
        if (BalanceDA(id)>=l){ 
        s-=l;
        String URL ="jdbc:derby://localhost:1527/ATMDA";
        try 
        {
            Connection conn = DriverManager.getConnection(URL);
            String sql = "UPDATE ATMUSER SET BALANCE="+s+" WHERE ID="+id;
            Statement st = conn.createStatement();
            st.executeUpdate(sql);

            st.close();
            conn.close();
        } 
        catch (SQLException ex) 
        {
            System.out.println("Connect failed ! ");
        }
        }
        else 
            System.out.println("Cant WitthDraw");
    }
    
    public static void DepositCash(int b,int id)
    {
        int s=BalanceDA(id);
        s+=b;
        
            String URL ="jdbc:derby://localhost:1527/ATMDA";
        try 
        {
            Connection conn = DriverManager.getConnection(URL);
            String sql = "UPDATE ATMUSER SET BALANCE="+s+" WHERE ID="+id;
            Statement st = conn.createStatement();
            st.executeUpdate(sql);

            st.close();
            conn.close();
        } 
        catch (SQLException ex) 
        {
            System.out.println("Connect failed ! ");
        }
    }
    
    public Boolean AcceptAmount(int b)
    {
        if(b<=Balance)
            return true;
        else 
            return false;
        
    }
    public void StoreData()
    {
       
        String URL ="jdbc:derby://localhost:1527/ATMDA";
        try
        {
         
         Connection conn = DriverManager.getConnection(URL);
         Statement st = conn.createStatement();
         String sql="INSERT INTO ATMUSER (ID,NAME,EMAIL,BALANCE,PINCODE) VALUES ("+this.getId()+",'"+this.getName()+"','"+this.getEmail()+"',"+Balance+","+ATMCard.getPin()+")" ;
         
         st.executeUpdate(sql);
         st.close();
         conn.close(); 
        }
         catch (SQLException ex) 
        {
            System.out.println("Connect Failed ! ");
            ex.printStackTrace();
            System.out.println(ex.getCause());
        }
    }
    
    public static int BalanceDA(int id)
    {
         String URL ="jdbc:derby://localhost:1527/ATMDA";

        try 
        {
            Connection conn = DriverManager.getConnection(URL);
            String sql = "SELECT BALANCE FROM ATMUSER WHERE ID ="+id;
            Statement st = conn.createStatement();
            ResultSet rs=st.executeQuery(sql);
          while(rs.next())
            {
                return rs.getInt("Balance");
            }
            rs.close();
            st.close();
            conn.close();
        } 
        catch (SQLException ex) 
        {
            System.out.println("Connection failed ! ");
            ex.printStackTrace();
            System.out.println(ex.getCause());
        }
        return 0;
    }
    public static boolean checkIP(int pin,int id)
    {
         String URL ="jdbc:derby://localhost:1527/ATMDA";
         
         try 
        {
            Connection conn = DriverManager.getConnection(URL);
            String sql = "SELECT PINCODE,ID FROM ATMUSER WHERE ID ="+id+"AND PINCODE ="+pin;
            Statement st = conn.createStatement();
            ResultSet rs=st.executeQuery(sql);
          while(rs.next())
            {
                if(rs.getInt("PinCode")==pin&&rs.getInt("Id")==id)
                {
                    return true ;
                }
                else return false;
            }
            rs.close();
            st.close();
            conn.close();
        } 
        catch (SQLException ex) 
        {
            System.out.println("Connection failed ! ");
            ex.printStackTrace();
            System.out.println(ex.getCause());
        }
        return false;
        
    }
    public static String NameDA(int id)
    {
        String URL ="jdbc:derby://localhost:1527/ATMDA";

        try 
        {
            Connection conn = DriverManager.getConnection(URL);
            String sql = "SELECT Name FROM ATMUSER WHERE ID ="+id;
            Statement st = conn.createStatement();
            ResultSet rs=st.executeQuery(sql);
          while(rs.next())
            {
                return rs.getString("Name");
                
            }
            rs.close();
            st.close();
            conn.close();
        } 
        catch (SQLException ex) 
        {
            System.out.println("Connection failed ! ");
            ex.printStackTrace();
            System.out.println(ex.getCause());
        }
        return "";
    }
    
    

    @Override
    public String toString() {
        return "ATMuser{" + "ATMCard=" + ATMCard + ", Acc=" + Acc + ", Balance=" + Balance + '}';
    }
    
    
}
