/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmsystem;

/**
 *
 * @author acc1
 */
public class Account {
    private int AccountNumber;
    private Transaction Trans;

    public Account(int AccountNumber, Transaction Trans) {
        this.AccountNumber = AccountNumber;
        this.Trans = Trans;
    }

    public int getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(int AccountNumber) {
        this.AccountNumber = AccountNumber;
    }


    public Transaction getTrans() {
        return Trans;
    }

    public void setTrans(Transaction Trans) {
        this.Trans = Trans;
    }

    @Override
    public String toString() {
        return "Account{" + "AccountNumber=" + AccountNumber + ", Balance="  + ", Trans=" + Trans + '}';
    }
    
    
}
