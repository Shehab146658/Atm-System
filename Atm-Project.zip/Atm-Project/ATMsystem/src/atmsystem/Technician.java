/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author acc1
 */
public class Technician extends Person
{
    private int phoneNumber;
    private int Salary;
    private AtmMachine ATMs;

    public Technician(int phoneNumber, int Salary, int id, String name, String Address, String Email) {
        super(id, name, Address, Email);
        this.phoneNumber = phoneNumber;
        this.Salary = Salary;
        
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    public AtmMachine getATMs() {
        return ATMs;
    }

    public void setATMs(AtmMachine ATMs) {
        this.ATMs = ATMs;
    }
    public void Maintenance()
    {
        if(ATMs.WorkingATM()==true)
            System.out.println("ATM under maintenance");
        else
            System.out.println("ATM is Functional");
            
    }
    public void FixAtm()
    {
        if(ATMs.WorkingATM()==false)
            System.out.println("Fixing ATM at: "+ATMs.getLocation());
        else
            System.out.println("ATM at : "+ATMs.getLocation()+"is functional");
            
    }
    
     public void TStoreData()
    {
       
          String URL ="jdbc:derby://localhost:1527/ATMDA";
        try
        {
         
         Connection conn = DriverManager.getConnection(URL);
         Statement st = conn.createStatement();
         String sql="INSERT INTO TECHNICIAN (ID,NAME,EMAIL,SALARY,PHONE) VALUES ("+this.getId()+",'"+this.getName()+"','"+this.getEmail()+"',"+Salary+","+phoneNumber+")" ;
         
         st.executeUpdate(sql);
         st.close();
         conn.close(); 
        }
         catch (SQLException ex) 
        {
            System.out.println("Connect Failed ! ");
            ex.printStackTrace();
            System.out.println(ex.getCause());
        }
    }
    
    @Override
    public String toString() {
        return "Technician{" + "phoneNumber=" + phoneNumber + ", Salary=" + Salary + ", ATMs=" + ATMs + '}';
    }
    
    
    
}
