/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author acc1
 */
public class AtmMachine {
    private int MacID;
    private String Location;
    private String BranchName;
    private int AtmState ;
    //if ATMSTate = 1 it meens the ATM is functional ,if ATm State = 0 it meens that ATM is notFunctional

    public AtmMachine(int MacID, String Location, String BranchName, int AtmState) {
        this.MacID = MacID;
        this.Location = Location;
        this.BranchName = BranchName;
        this.AtmState = AtmState;
    }
    
 

  
    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public String getBranchName() {
        return BranchName;
    }

    public void setBranchName(String BranchName) {
        this.BranchName = BranchName;
    }
    
    public int getAtmState() {
        return AtmState;
    }

    public void setAtmState(int AtmState) {
        this.AtmState = AtmState;
    }
    public Boolean WorkingATM()
    {
        if(AtmState==1)
            return true;
        else 
            return false;
    }
    public String GETATMState()
    {
        if(AtmState==1)
            return "Functional";
        else 
            return "Not Functional";
    }
    public void ATMStoreData()
    {
       
          String URL ="jdbc:derby://localhost:1527/ATMDA";
        try
        {
         
         Connection conn = DriverManager.getConnection(URL);
         Statement st = conn.createStatement();
         String sql="INSERT INTO ATMMACHINE (ID,LOCATION,ATMSTATE,BRANCHNAME) VALUES ("+MacID+",'"+Location+"',"+this.WorkingATM()+",'"+this.BranchName+"')";
         
         st.executeUpdate(sql);
         st.close();
         conn.close(); 
        }
         catch (SQLException ex) 
        {
            System.out.println("Connect Failed ! ");
            ex.printStackTrace();
            System.out.println(ex.getCause());
        }
    }

    @Override
    public String toString() {
        return "AtmMachine{" + "Location=" + Location + ", BranchName=" + BranchName + ", AtmState=" + GETATMState() + '}';
    }

}
