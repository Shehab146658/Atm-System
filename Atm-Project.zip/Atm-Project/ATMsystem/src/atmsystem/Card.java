/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmsystem;

/**
 *
 * @author acc1
 */
public class Card {
    private int pin;
    private int CardID;
    private Account Acc;

    public Card(int pin, int CardID) {
        this.pin = pin;
        this.CardID = CardID;
      
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public int getCardID() {
        return CardID;
    }

    public void setCardID(int CardID) {
        this.CardID = CardID;
    }

    public Account getAcc() {
        return Acc;
    }

    public void setAcc(Account Acc) {
        this.Acc = Acc;
    }

    @Override
    public String toString() {
        return "Card{" + "pin=" + pin + ", CardID=" + CardID + ", Acc=" + Acc + '}';
    }
    
    
}
