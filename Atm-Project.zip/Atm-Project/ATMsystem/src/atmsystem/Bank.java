/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmsystem;

/**
 *
 * @author acc1
 */
public class Bank {
    private int Code;
    private String Address;
    private AtmMachine []WorkingATM;

    public Bank(int Code, String Address, AtmMachine[] WorkingATM) {
        this.Code = Code;
        this.Address = Address;
        this.WorkingATM = WorkingATM;
    }

    public int getCode() {
        return Code;
    }

    public void setCode(int Code) {
        this.Code = Code;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public AtmMachine[] getWorkingATM() {
        return WorkingATM;
    }

    public void setWorkingATM(AtmMachine[] WorkingATM) {
        this.WorkingATM = WorkingATM;
    }
    public void ViewWorkingAtms()
    {
      
        for (int i =0;i<  WorkingATM.length;i++)
        {
              if(WorkingATM[i].WorkingATM()==true)
              {
                 System.out.println("ATM at "+WorkingATM[i].getLocation()+"is Functional");
              }
        }
    }

    @Override
    public String toString() {
        return "Bank{" + "Code=" + Code + ", Address=" + Address + ", WorkingATM=" + WorkingATM + '}';
    }
    
    
    
}
