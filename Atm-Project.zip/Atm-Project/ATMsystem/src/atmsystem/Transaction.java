/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmsystem;

/**
 *
 * @author acc1
 */
public class Transaction {
    
    private String Date;
    private float Amount;

    public Transaction(String Date, float Amount) {
        this.Date = Date;
        this.Amount = Amount;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public float getAmount() {
        return Amount;
    }

    public void setAmount(float Amount) {
        this.Amount = Amount;
    }
    public void CancelTransaction()
    {
        Amount=0;
        System.out.println("Transaction Canceled...");
    }

    @Override
    public String toString() {
        return "Transaction{" + "Date=" + Date + ", Amount=" + Amount + '}';
    }
    
    
        
    
    
    
}
