/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmsystem;

import static atmsystem.ATMuser.*;



public class ATMsystem {

    public static void main(String[] args) {
        
//      Card y= new Card(3654,3261315); 
//      ATMuser x= new ATMuser(y,3000,147511,"Kareem","Rehab","Kmba501");
//      System.out.println(x);
//
//      System.out.println(BalanceDA(6000));
//      withdrawCash(3000,155600);
//      System.out.println(checkIP(5014,155600));  
        
        }
        
    }
    

